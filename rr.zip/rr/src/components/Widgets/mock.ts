export const mock = [
	{
		id: 'i-0',
		content: 'Title & Descr',
		checked: false,
	},
	{
		id: 'i-1',
		content: 'Main Info',
		checked: false,
	},
	{
		id: 'i-2',
		content: 'Keywords',
		checked: false,
	},
	{
		id: 'i-3',
		content: 'Assignees',
		checked: false,
	},
	{
		id: 'i-4',
		content: 'Collections',
		checked: false,
	},
	{
		id: 'i-5',
		content: 'Lightboards',
		checked: false,
	},
	{
		id: 'i-6',
		content: 'Asset marks',
		checked: false,
	},
	{
		id: 'i-7',
		content: 'Share',
		checked: false,
	},
	{
		id: 'i-8',
		content: 'Restrict',
		checked: false,
	},
	{
		id: 'i-9',
		content: 'Custom fields',
		checked: false,
	},
	{
		id: 'i-10',
		content: 'GPS',
		checked: false,
	},
	{
		id: 'i-11',
		content: 'Map',
		checked: false,
	},
];
