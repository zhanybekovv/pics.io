export type Props = {
	readonly id: string;
	readonly content: string;
	checked: boolean;
};

export type Checked = {
	checked: boolean;
};
