export type Props = {
	readonly lol?: string;
};
