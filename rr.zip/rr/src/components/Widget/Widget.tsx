import React, { FC } from 'react';
import { Props } from './types';

const Widget: FC<Props> = () => {
	return <div>Widget1</div>;
};

export default Widget;
